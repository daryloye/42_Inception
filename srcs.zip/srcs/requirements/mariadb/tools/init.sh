#!/bin/bash

# Start MariaDB in the background
mysqld_safe &

# Wait until MariaDB is ready
until mysqladmin ping --silent; do
  sleep 1
done

# Run the init SQL script
mysql < /init.sql

# Keep MariaDB running in the foreground
wait
